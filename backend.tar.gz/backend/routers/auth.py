from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.core.database import get_db
from backend.core.security import verify_password, get_password_hash, create_access_token
from backend.core.email_service import notify_bonus
from backend.models.models import (
    User,
    PromoCode,
    Transaction,
    TransactionType,
    TransactionStatus,
)

from backend.schemas.schemas import UserRegister, UserLogin, Token
from datetime import datetime
import secrets, threading
import os


router = APIRouter(prefix="/auth", tags=["Authentication"])


def generate_wallet():
    return "0x" + secrets.token_hex(20)

def _send_bonus_email_async(email, name, amount, reason, user_id):
    """Send bonus notification in background thread so registration doesn't block."""
    from backend.core.database import SessionLocal
    db = SessionLocal()
    try:
        notify_bonus(email, name, amount, reason, db, user_id)
        db.commit()
    except Exception as e:
        db.rollback()
        print(f"Bonus email error: {e}")
    finally:
        db.close()

@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
def register(data: UserRegister, db: Session = Depends(get_db)):

    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    # ── Validate promo code if provided ─────────────────────────
    promo = None
    bonus_amount = 0.0
    promo_reason = ""

    if data.promo_code:
        code_str = data.promo_code.strip().upper()
        promo = db.query(PromoCode).filter(
            PromoCode.code == code_str,
            PromoCode.is_active == True
        ).first()
        if not promo:
            raise HTTPException(status_code=400, detail="Invalid or expired promo code")
        if promo.used_count >= promo.max_uses:
            raise HTTPException(status_code=400, detail="Promo code has reached its usage limit")
        if promo.expires_at and datetime.utcnow() > promo.expires_at:
            raise HTTPException(status_code=400, detail="Promo code has expired")
        bonus_amount = promo.bonus_amount
        promo_reason = f"promo code <strong>{code_str}</strong> applied"

    # ── Create user (email_verified=True — no verification required) ──
    user = User(
        email=data.email,
        full_name=data.full_name,
        hashed_password=get_password_hash(data.password),
        mobile=data.mobile,
        country=data.country,
        address=data.address,
        city=data.city,
        state=data.state,
        date_of_birth=data.date_of_birth,
        wallet_address=generate_wallet(),
        balance=bonus_amount,
        bonus_credited=bool(promo),
        promo_code_used=promo.code if promo else None,
        email_verified=True,
        registration_completed=True,
    )

    db.add(user)
    db.flush()  # get user.id before commit

    # ── Credit bonus transaction (only when promo is provided/valid) ─────────
    if promo:
        bonus_tx = Transaction(
            user_id=user.id,
            type=TransactionType.BONUS,
            amount=bonus_amount,
            status=TransactionStatus.COMPLETED,
            description=f"Welcome bonus — {promo_reason}",
            reference="BON-" + secrets.token_hex(6).upper()
        )
        db.add(bonus_tx)
        promo.used_count += 1

    db.commit()
    db.refresh(user)

    token = create_access_token({"sub": user.email})

    # ── Send bonus email async ───────────────────────────────────
    if promo:
        threading.Thread(
            target=_send_bonus_email_async,
            args=(user.email, user.full_name, bonus_amount, promo_reason, user.id),
            daemon=True
        ).start()

    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": 3600,
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "mobile": user.mobile,
            "country": user.country,
            "address": user.address,
            "city": user.city,
            "state": user.state,
            "date_of_birth": user.date_of_birth,
            "balance": user.balance,
            "wallet_address": user.wallet_address,
            "kyc_status": user.kyc_status,
            "is_admin": user.is_admin,
            "email_verified": True,
            "bonus_amount": bonus_amount,
            "promo_used": promo.code if promo else None,
        }
    }


@router.post("/login", response_model=Token)
def login(data: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is disabled")

    token = create_access_token({"sub": user.email})
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": 3600,
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "balance": user.balance,
            "wallet_address": user.wallet_address,
            "kyc_status": user.kyc_status,
            "is_admin": user.is_admin,
            "email_verified": True,
            "promo_used": user.promo_code_used,
        }
    }


@router.get("/validate-promo/{code}")
def validate_promo(code: str, db: Session = Depends(get_db)):
    """Check a promo code before registration."""
    promo = db.query(PromoCode).filter(
        PromoCode.code == code.strip().upper(),
        PromoCode.is_active == True
    ).first()
    if not promo or promo.used_count >= promo.max_uses:
        raise HTTPException(status_code=404, detail="Invalid or expired promo code")
    if promo.expires_at and datetime.utcnow() > promo.expires_at:
        raise HTTPException(status_code=404, detail="Promo code has expired")
    return {"valid": True, "bonus_amount": promo.bonus_amount, "description": promo.description}
