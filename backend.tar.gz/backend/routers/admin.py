from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from backend.core.database import get_db
from backend.core.security import get_current_user
from backend.models.models import (User, KYCSubmission, KYCStatus, PromoCode,
                                    Transaction, Investment, InvestmentStatus,
                                    EmailNotificationLog, AdminSettings, LoanRequest,
                                    InvestmentPlan, ClaimBlack, ClaimStatus)
from backend.core.email_service import notify_kyc_approved, notify_kyc_rejected
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
import secrets, threading, math

router = APIRouter(prefix="/admin", tags=["Admin"])

def admin_required(current_user: User = Depends(get_current_user)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

# ── Dashboard Stats ──────────────────────────────────────────────────────────

@router.get("/stats")
def admin_stats(admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    from backend.services.claim_service import ClaimService
    claim_service = ClaimService(db)
    total_users = db.query(User).count()
    total_balance = db.query(func.sum(User.balance)).scalar() or 0
    total_invested = db.query(func.sum(User.total_invested)).scalar() or 0
    total_profit_paid = db.query(func.sum(User.total_profit)).scalar() or 0
    active_investments = db.query(Investment).filter(Investment.status == InvestmentStatus.ACTIVE).count()
    pending_kyc = db.query(KYCSubmission).filter(KYCSubmission.status == KYCStatus.PENDING).count()
    total_transactions = db.query(Transaction).count()
    emails_sent = db.query(EmailNotificationLog).count()
    pending_withdrawals = db.query(Transaction).filter(
        Transaction.type == "withdrawal", Transaction.status == "pending"
    ).count()

    pending_claims = db.query(ClaimBlack).filter(
        ClaimBlack.status.in_(["pending", "under_review"])
    ).count()

    # Recent signups (last 7 days)
    from datetime import timedelta
    week_ago = datetime.utcnow() - timedelta(days=7)
    new_users_week = db.query(User).filter(User.created_at >= week_ago).count()

    return {
        "total_users": total_users,
        "new_users_this_week": new_users_week,
        "total_balance_on_platform": round(total_balance, 2),
        "total_invested": round(total_invested, 2),
        "total_profit_paid": round(total_profit_paid, 2),
        "active_investments": active_investments,
        "pending_kyc_reviews": pending_kyc,
        "pending_withdrawals": pending_withdrawals,
        "pending_claims": pending_claims,
        "total_transactions": total_transactions,
        "emails_sent": emails_sent,
    }

    return {
        "total_users": total_users,
        "new_users_this_week": new_users_week,
        "total_balance_on_platform": round(total_balance, 2),
        "total_invested": round(total_invested, 2),
        "total_profit_paid": round(total_profit_paid, 2),
        "active_investments": active_investments,
        "pending_kyc_reviews": pending_kyc,
        "pending_withdrawals": pending_withdrawals,
        "total_transactions": total_transactions,
        "emails_sent": emails_sent,
    }

# ── Users Management ─────────────────────────────────────────────────────────

@router.get("/users")
def list_users(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    kyc_filter: Optional[str] = None,
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db)
):
    q = db.query(User)
    if search:
        q = q.filter(
            (User.email.ilike(f"%{search}%")) | (User.full_name.ilike(f"%{search}%"))
        )
    if kyc_filter:
        q = q.filter(User.kyc_status == kyc_filter)
    total = q.count()
    users = q.order_by(desc(User.created_at)).offset((page-1)*per_page).limit(per_page).all()
    return {
        "items": [{
            "id": u.id, "email": u.email, "full_name": u.full_name,
            "balance": round(u.balance, 2), "total_invested": round(u.total_invested, 2),
            "total_profit": round(u.total_profit, 2), "kyc_status": u.kyc_status.value,
            "is_active": u.is_active, "is_admin": u.is_admin,
            "promo_code_used": u.promo_code_used, "created_at": u.created_at.isoformat()
        } for u in users],
        "total": total, "page": page, "pages": max(1, math.ceil(total/per_page))
    }

class UserWalletUpdateData(BaseModel):
    btc_wallet_address: Optional[str] = ""
    usdt_wallet_address: Optional[str] = ""

class UserUpdateData(BaseModel):
    balance: Optional[float] = None
    is_active: Optional[bool] = None
    is_admin: Optional[bool] = None
    email_notifications: Optional[bool] = None

@router.patch("/users/{user_id}")
def update_user(user_id: int, data: UserUpdateData,
                admin: User = Depends(admin_required), db: Session = Depends(get_db)):

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if data.balance is not None:
        user.balance = data.balance
    if data.is_active is not None:
        user.is_active = data.is_active
    if data.is_admin is not None:
        user.is_admin = data.is_admin
    if data.email_notifications is not None:
        user.email_notifications = data.email_notifications
    db.commit()
    return {"message": "User updated", "user_id": user_id}

@router.patch("/users/{user_id}/wallets")
def set_user_wallets(
    user_id: int,
    data: UserWalletUpdateData,
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db),
):

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Allow empty strings (admin can clear wallets), but store stripped values.
    user.btc_wallet_address = (data.btc_wallet_address or "").strip()
    user.usdt_wallet_address = (data.usdt_wallet_address or "").strip()
    db.commit()
    return {
        "message": "Wallets updated",
        "user_id": user_id,
        "btc_wallet_address": user.btc_wallet_address,
        "usdt_wallet_address": user.usdt_wallet_address,
    }

@router.get("/users/{user_id}/detail")
def user_detail(user_id: int, admin: User = Depends(admin_required), db: Session = Depends(get_db)):

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    txs = db.query(Transaction).filter(Transaction.user_id == user_id).order_by(desc(Transaction.created_at)).limit(10).all()
    invs = db.query(Investment).filter(Investment.user_id == user_id).order_by(desc(Investment.start_date)).limit(5).all()
    return {
        "user": {
            "id": user.id, "email": user.email, "full_name": user.full_name,
            "balance": round(user.balance, 2), "total_invested": round(user.total_invested, 2),
            "total_profit": round(user.total_profit, 2), "kyc_status": user.kyc_status.value,
            "is_active": user.is_active, "is_admin": user.is_admin,
        "email_notifications": user.email_notifications,
        "promo_code_used": user.promo_code_used,
        "wallet_address": user.wallet_address,
        "btc_wallet_address": getattr(user, "btc_wallet_address", None),
        "usdt_wallet_address": getattr(user, "usdt_wallet_address", None),
        "created_at": user.created_at.isoformat()

        },
        "recent_transactions": [{"id":t.id,"type":t.type,"amount":t.amount,"status":t.status,"created_at":t.created_at.isoformat()} for t in txs],
        "investments": [{"id":i.id,"plan_id":i.plan_id,"amount":i.amount,"status":i.status,"profit":i.total_profit_earned} for i in invs],
    }

# ── KYC Management ───────────────────────────────────────────────────────────

@router.get("/kyc")
def list_kyc(
    page: int = Query(1, ge=1),
    status_filter: Optional[str] = "pending",
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db)
):
    q = db.query(KYCSubmission)
    if status_filter and status_filter != "all":
        q = q.filter(KYCSubmission.status == status_filter)
    total = q.count()
    subs = q.order_by(desc(KYCSubmission.submitted_at)).offset((page-1)*20).limit(20).all()
    return {
        "items": [{
            "id": s.id, "user_id": s.user_id,
            "user_email": s.user.email, "user_name": s.user.full_name,
            "document_type": s.document_type.value,
            "document_number": s.document_number,
            "full_name": s.full_name, "date_of_birth": s.date_of_birth,
            "country": s.country, "address": s.address,
            "status": s.status.value, "rejection_reason": s.rejection_reason,
            "submitted_at": s.submitted_at.isoformat(),
            "reviewed_at": s.reviewed_at.isoformat() if s.reviewed_at else None,
        } for s in subs],
        "total": total, "page": page, "pages": max(1, math.ceil(total/20))
    }

class KYCReviewData(BaseModel):
    action: str  # "approve" | "reject"
    rejection_reason: Optional[str] = None

@router.post("/kyc/{submission_id}/review")
def review_kyc(
    submission_id: int, data: KYCReviewData,
    admin: User = Depends(admin_required), db: Session = Depends(get_db)
):
    sub = db.query(KYCSubmission).filter(KYCSubmission.id == submission_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="KYC submission not found")
    user = db.query(User).filter(User.id == sub.user_id).first()

    if data.action == "approve":
        sub.status = KYCStatus.APPROVED
        user.kyc_status = KYCStatus.APPROVED
        sub.reviewed_at = datetime.utcnow()
        sub.reviewed_by = admin.id
        db.commit()
        # Send approval email
        from backend.core.database import SessionLocal
        threading.Thread(
            target=notify_kyc_approved,
            args=(user.email, user.full_name, SessionLocal(), user.id),
            daemon=True
        ).start()
        return {"message": f"KYC approved for {user.email}"}

    elif data.action == "reject":
        if not data.rejection_reason:
            raise HTTPException(status_code=400, detail="Rejection reason required")
        sub.status = KYCStatus.REJECTED
        user.kyc_status = KYCStatus.REJECTED
        sub.rejection_reason = data.rejection_reason
        sub.reviewed_at = datetime.utcnow()
        sub.reviewed_by = admin.id
        db.commit()
        from backend.core.database import SessionLocal
        threading.Thread(
            target=notify_kyc_rejected,
            args=(user.email, user.full_name, data.rejection_reason, SessionLocal(), user.id),
            daemon=True
        ).start()
        return {"message": f"KYC rejected for {user.email}"}
    else:
        raise HTTPException(status_code=400, detail="Action must be 'approve' or 'reject'")

# ── Promo Codes ──────────────────────────────────────────────────────────────

@router.get("/promo-codes")
def list_promos(admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    codes = db.query(PromoCode).order_by(desc(PromoCode.created_at)).all()
    return [{"id":c.id,"code":c.code,"bonus_amount":c.bonus_amount,"max_uses":c.max_uses,
             "used_count":c.used_count,"is_active":c.is_active,"description":c.description,
             "created_at":c.created_at.isoformat(),"expires_at":c.expires_at.isoformat() if c.expires_at else None}
            for c in codes]

class PromoCreateData(BaseModel):
    code: Optional[str] = None  # auto-generate if blank
    bonus_amount: float = 100.0
    max_uses: int = 100
    description: str = ""

@router.post("/promo-codes")
def create_promo(data: PromoCreateData, admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    code_str = (data.code or secrets.token_hex(4)).strip().upper()
    if db.query(PromoCode).filter(PromoCode.code == code_str).first():
        raise HTTPException(status_code=400, detail="Promo code already exists")
    promo = PromoCode(
        code=code_str, bonus_amount=data.bonus_amount,
        max_uses=data.max_uses, description=data.description
    )
    db.add(promo); db.commit(); db.refresh(promo)
    return {"message": "Promo code created", "code": promo.code, "bonus_amount": promo.bonus_amount}

@router.patch("/promo-codes/{code_id}")
def toggle_promo(code_id: int, admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    promo = db.query(PromoCode).filter(PromoCode.id == code_id).first()
    if not promo:
        raise HTTPException(status_code=404, detail="Promo code not found")
    promo.is_active = not promo.is_active
    db.commit()
    return {"message": f"Promo {'activated' if promo.is_active else 'deactivated'}", "is_active": promo.is_active}

@router.delete("/promo-codes/{code_id}")
def delete_promo(code_id: int, admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    promo = db.query(PromoCode).filter(PromoCode.id == code_id).first()
    if not promo:
        raise HTTPException(status_code=404, detail="Not found")
    db.delete(promo); db.commit()
    return {"message": "Deleted"}

# ── Investment Plans Management ──────────────────────────────────────────────

class PlanUpdateData(BaseModel):
    name: Optional[str] = None
    daily_roi: Optional[float] = None
    min_amount: Optional[float] = None
    max_amount: Optional[float] = None
    duration_days: Optional[int] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None

@router.patch("/plans/{plan_id}")
def update_plan(plan_id: int, data: PlanUpdateData,
                admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    plan = db.query(InvestmentPlan).filter(InvestmentPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    for field, val in data.model_dump(exclude_none=True).items():
        setattr(plan, field, val)
    db.commit()
    return {"message": "Plan updated"}

# ── Deposit Management ─────────────────────────────────────────────────────

class DepositActionData(BaseModel):
    action: str  # "approve" | "reject"

@router.post("/deposits/{tx_id}/action")
def action_deposit(tx_id: int, data: DepositActionData,
                    admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    tx = db.query(Transaction).filter(
        Transaction.id == tx_id, Transaction.type == "deposit"
    ).first()
    if not tx:
        raise HTTPException(status_code=404, detail="Deposit not found")

    if tx.status != "pending":
        raise HTTPException(status_code=400, detail="Deposit already processed")

    user = db.query(User).filter(User.id == tx.user_id).first()

    if data.action == "approve":
        # Credit balance
        if user:
            user.balance += tx.amount
        tx.status = "completed"
        db.commit()
        return {"message": "Deposit approved"}

    if data.action == "reject":
        tx.status = "failed"
        db.commit()
        return {"message": "Deposit rejected"}

    raise HTTPException(status_code=400, detail="Invalid action")

# ── Withdrawal Management ────────────────────────────────────────────────────

@router.get("/withdrawals")
def list_withdrawals(

    page: int = Query(1, ge=1),
    status_filter: str = "pending",
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db)
):
    q = db.query(Transaction).filter(Transaction.type == "withdrawal")
    if status_filter != "all":
        q = q.filter(Transaction.status == status_filter)
    total = q.count()
    items = q.order_by(desc(Transaction.created_at)).offset((page-1)*20).limit(20).all()
    return {
        "items": [{
            "id": t.id, "user_id": t.user_id,
            "user_email": t.user.email, "user_name": t.user.full_name,
            "amount": t.amount, "status": t.status, "reference": t.reference,
            "description": t.description, "created_at": t.created_at.isoformat()
        } for t in items],
        "total": total, "page": page, "pages": max(1, math.ceil(total/20))
    }

class WithdrawalActionData(BaseModel):
    action: str  # "approve" | "reject"

@router.post("/withdrawals/{tx_id}/action")
def action_withdrawal(tx_id: int, data: WithdrawalActionData,
                      admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    tx = db.query(Transaction).filter(
        Transaction.id == tx_id, Transaction.type == "withdrawal"
    ).first()
    if not tx:
        raise HTTPException(status_code=404, detail="Withdrawal not found")
    if tx.status != "pending":
        raise HTTPException(status_code=400, detail="Already processed")

    if data.action == "approve":
        tx.status = "completed"
        db.commit()
        return {"message": "Withdrawal approved"}
    elif data.action == "reject":
        # Refund balance
        user = db.query(User).filter(User.id == tx.user_id).first()
        if user:
            user.balance += tx.amount
        tx.status = "failed"
        db.commit()
        return {"message": "Withdrawal rejected and amount refunded"}
    raise HTTPException(status_code=400, detail="Invalid action")

# ── SMTP / Email Settings ────────────────────────────────────────────────────

class UserWalletUpdateData(BaseModel):
    btc_wallet_address: Optional[str] = ""
    usdt_wallet_address: Optional[str] = ""


class SMTPSettings(BaseModel):
    smtp_host: str

    smtp_port: int = 587
    smtp_user: str
    smtp_pass: str
    smtp_from: str
    smtp_tls: bool = True

@router.get("/settings/smtp")
def get_smtp(admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    keys = ["smtp_host","smtp_port","smtp_user","smtp_from","smtp_tls"]
    rows = db.query(AdminSettings).filter(AdminSettings.key.in_(keys)).all()
    return {r.key: r.value for r in rows}

@router.post("/settings/smtp")
def save_smtp(data: SMTPSettings, admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    settings_map = {
        "smtp_host": data.smtp_host, "smtp_port": str(data.smtp_port),
        "smtp_user": data.smtp_user, "smtp_pass": data.smtp_pass,
        "smtp_from": data.smtp_from, "smtp_tls": str(data.smtp_tls).lower()
    }
    for key, val in settings_map.items():
        row = db.query(AdminSettings).filter(AdminSettings.key == key).first()
        if row:
            row.value = val
        else:
            db.add(AdminSettings(key=key, value=val))
    db.commit()
    return {"message": "SMTP settings saved"}

@router.post("/settings/smtp/test")
def test_smtp(to_email: str, admin: User = Depends(admin_required), db: Session = Depends(get_db)):
    from backend.core.email_service import send_email
    ok = send_email(
        to_email, "CryptoVault SMTP Test",
        "<h2>SMTP Test</h2><p>Your email configuration is working correctly! 🎉</p>",
        db, admin.id, "test"
    )
    return {"success": ok, "message": "Test email sent!" if ok else "Failed — check SMTP settings"}

# ── Email Notification Logs ──────────────────────────────────────────────────

@router.get("/email-logs")
def email_logs(
    page: int = Query(1, ge=1),
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db)
):
    q = db.query(EmailNotificationLog).order_by(desc(EmailNotificationLog.sent_at))
    total = q.count()
    items = q.offset((page-1)*30).limit(30).all()
    return {
        "items": [{
            "id": l.id, "user_id": l.user_id, "recipient": l.recipient_email,
            "subject": l.subject, "type": l.notification_type,
            "status": l.status, "sent_at": l.sent_at.isoformat()
        } for l in items],
        "total": total, "page": page, "pages": max(1, math.ceil(total/30))
    }

# ── Platform Transactions ────────────────────────────────────────────────────

@router.get("/transactions")
def all_transactions(
    page: int = Query(1, ge=1),
    type_filter: Optional[str] = None,
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db)
):
    q = db.query(Transaction)
    if type_filter:
        q = q.filter(Transaction.type == type_filter)
    total = q.count()
    items = q.order_by(desc(Transaction.created_at)).offset((page-1)*30).limit(30).all()
    return {
        "items": [{
            "id": t.id, "user_id": t.user_id,
            "user_email": t.user.email,
            "type": t.type, "amount": t.amount, "status": t.status,
            "reference": t.reference, "description": t.description,
            "created_at": t.created_at.isoformat()
        } for t in items],
        "total": total, "page": page, "pages": max(1, math.ceil(total/30))
    }

# ═─ Claims & Recovery Management ────────────────────────────────────────────

class ClaimReviewData(BaseModel):
    action: str  # "approve" | "reject"
    notes: Optional[str] = None
    amount_recovered: Optional[float] = None
    recovery_days: Optional[int] = None

@router.get("/claims")
def list_claims(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    status_filter: Optional[str] = "pending",
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db)
):
    q = db.query(ClaimBlack).order_by(desc(ClaimBlack.created_at))
    if status_filter and status_filter != "all":
        q = q.filter(ClaimBlack.status == status_filter)
    total = q.count()
    claims = q.offset((page-1)*per_page).limit(per_page).all()
    return {
        "items": [{
            "id": c.id,
            "case_id": c.case_id,
            "claimant": f"{c.first_name} {c.last_name}".strip(),
            "email": c.email,
            "amount": c.amount_invested,
            "scam_type": c.scam_type.replace('_', ' ').title(),
            "priority": c.priority,
            "status": c.status.value if hasattr(c.status, 'value') else c.status,
            "specialist": c.assigned_specialist or 'Unassigned',
            "created": c.created_at.isoformat() if c.created_at else None,
            "updated": c.updated_at.isoformat() if c.updated_at else None,
            "amount_recovered": float(c.amount_recovered or 0),
            "recovery_days": c.recovery_days or 0,
        } for c in claims],
        "total": total,
        "page": page,
        "pages": max(1, math.ceil(total/per_page)),
        "page_size": per_page,
        "status_filter": status_filter
    }

@router.post("/claims/{case_id}/review")
def review_claim(
    case_id: str,
    data: ClaimReviewData,
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db)
):
    claim = db.query(ClaimBlack).filter(ClaimBlack.case_id == case_id.upper()).first()
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")

    current_status = claim.status.value if hasattr(claim.status, 'value') else claim.status
    if current_status in ("recovered", "rejected", "closed"):
        raise HTTPException(status_code=400, detail=f"Claim already {current_status}")

    if data.action == "approve":
        claim.status = ClaimStatus.RECOVERED
        claim.updated_at = datetime.utcnow()
        if data.amount_recovered is not None:
            claim.amount_recovered = data.amount_recovered
        if data.recovery_days is not None:
            claim.recovery_days = data.recovery_days
        else:
            claim.recovery_days = (claim.updated_at - claim.created_at).days if claim.created_at else 0
        if data.notes:
            claim.case_description += f"\n\n--- ADMIN APPROVAL {datetime.utcnow().strftime('%Y-%m-%d %H:%M')} ---\n{data.notes}"
        db.commit()
        return {"message": f"Claim {case_id} approved", "case_id": case_id, "new_status": "recovered"}

    elif data.action == "reject":
        claim.status = ClaimStatus.REJECTED
        claim.updated_at = datetime.utcnow()
        if data.notes:
            claim.case_description += f"\n\n--- ADMIN REJECTION {datetime.utcnow().strftime('%Y-%m-%d %H:%M')} ---\n{data.notes}"
        db.commit()
        return {"message": f"Claim {case_id} rejected", "case_id": case_id, "new_status": "rejected"}

    else:
        raise HTTPException(status_code=400, detail="Action must be 'approve' or 'reject'")
