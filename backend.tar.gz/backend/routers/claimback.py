from fastapi import APIRouter, Depends, HTTPException, status, Body, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, or_, desc
from backend.core.database import get_db
from backend.core.security import get_current_user
from backend.models.models import User, ClaimBlack, ClaimStatus
from backend.schemas.schemas import ClaimReportCreate, ClaimReportResponse, BaseModel
from backend.core.email_service import send_email
from backend.services.claim_service_fixed import ClaimService
from typing import List, Optional
from fastapi import Query
from datetime import datetime, timedelta
import secrets
import logging

# Configure logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/claimback", tags=["Claimback & Recovery"])

# Dependency to get claim service
def get_claim_service(db: Session = Depends(get_db)):
    return ClaimService(db)

def admin_required(current_user: User = Depends(get_current_user)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

@router.post("/user/scam-report", 
             response_model=ClaimReportResponse,
             status_code=status.HTTP_201_CREATED,
             summary="Submit Scam Recovery Report (User Dashboard)",
             description="Dashboard form submission endpoint.")
async def submit_scam_report(
    report_data: ClaimReportCreate = Body(...),
    current_user: Optional[User] = Depends(get_current_user),
    db: Session = Depends(get_db),
    claim_service: ClaimService = Depends(get_claim_service)
):
    """
    User scam recovery form submission from dashboard.html.
    """
    # Form field mapping (dashboard sends slightly different fields)
    mapped_data = {
        'first_name': report_data.first_name or getattr(current_user, 'full_name', '').split()[0],
        'last_name': report_data.last_name or '',
        'email': report_data.email or getattr(current_user, 'email', ''),
        'mobile': report_data.mobile,
        'country': report_data.country,
        'scam_type': report_data.scam_type,
        'amount_invested': report_data.amount_invested,
        'case_description': report_data.case_description
    }
    
    # Generate unique case ID
    case_id = f"REC-{secrets.token_hex(6).upper()}"
    
    # Create claim record (user optional)
    claim_record = ClaimBlack(
        case_id=case_id,
        first_name=mapped_data['first_name'].strip(),
        last_name=mapped_data['last_name'].strip(),
        email=mapped_data['email'].strip().lower(),
        mobile=mapped_data['mobile'].strip(),
        country=mapped_data['country'],
        scam_type=mapped_data['scam_type'],
        amount_invested=mapped_data['amount_invested'],
        case_description=mapped_data['case_description'].strip(),
        user_id=current_user.id if current_user else None,
        status=ClaimStatus.PENDING.value,
        priority=claim_service.calculate_priority(mapped_data),
        created_at=datetime.utcnow()
    )
    
    db.add(claim_record)
    db.commit()
    db.refresh(claim_record)
    
    # Auto-triage
    claim_service.triage_case(claim_record)
    
    # Send confirmation (async non-blocking)
    try:
        body_html = f"""
        <h2>✅ Recovery Case Submitted</h2>
        <p>Dear <strong>{claim_record.first_name} {claim_record.last_name}</strong>,</p>
        <div style='text-align:center;padding:24px;background:#0a0f1e;border-radius:12px;margin:20px 0;'>
          <div style='font-size:1rem;color:#6b7fa3;'>CASE ID</div>
          <div style='font-size:1.8rem;font-weight:800;color:#00d4aa;font-family:monospace;'>{case_id}</div>
          <div style='color:#6b7fa3;margin-top:8px;'>${claim_record.amount_invested:,.0f} - {claim_record.scam_type.replace('_', ' ').title()}</div>
        </div>
        <p>Our recovery team has been notified. Expect contact within 24-48 hours (Priority: {claim_record.priority}/5).</p>
        """
        send_email(
            to_email=claim_record.email,
            subject=f"Recovery Case Created: {case_id}",
            body_html=body_html,
            db=db,
            user_id=current_user.id if current_user else 0,
            notification_type="recovery_case"
        )
    except:
        pass  # Non-blocking
    
    logger.info(f"New claim from dashboard: {case_id} - Data: {report_data.dict()}")
    
    return ClaimReportResponse(
        success=True,
        case_id=case_id,
        message="Case submitted successfully! Check email for confirmation.",
        next_steps=["Review email", "Track progress", "Expect specialist contact"],
        recovery_stats=claim_service.get_recovery_stats()
    )

@router.get("/scam-report/{case_id}", 
           response_model=ClaimReportResponse,
           summary="Get Case Status",
           description="Retrieve detailed status and updates for a specific recovery case.")
async def get_case_status(
    case_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    claim_service: ClaimService = Depends(get_claim_service)
):
    """Retrieve case status and recovery progress."""
    case = db.query(ClaimBlack).filter(
        ClaimBlack.case_id == case_id.upper()
    ).first()
    
    if not case:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Case not found. Please verify case ID."
        )
    
    # Authorization check (user or public read for own cases)
    if current_user and current_user.id != case.user_id:
        # Allow email/mobile lookup for case owners
        if current_user.email != case.email:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Unauthorized access to case"
            )
    
    return ClaimReportResponse(
        success=True,
        case_id=case.case_id,
        status=case.status,
        priority=case.priority,
        amount_recovered=case.amount_recovered or 0,
        created_at=case.created_at.isoformat(),
        last_updated=case.updated_at.isoformat() if case.updated_at else None,
        assigned_specialist=case.assigned_specialist,
        message=f"Case {case.case_id} - {claim_service.get_status_message(case.status)}",
        recovery_stats=claim_service.get_recovery_stats()
    )

@router.get("/stats", 
           response_model=dict,
           summary="Recovery Program Statistics",
           description="Public statistics on recovery success rates and program performance.")
async def get_recovery_stats(
    db: Session = Depends(get_db),
    claim_service: ClaimService = Depends(get_claim_service)
):
    """Public endpoint for recovery program transparency."""
    stats = claim_service.get_recovery_stats()

    # Ensure response is fully JSON-serializable (no SQLAlchemy Row objects).
    sanitized_stats = dict(stats)
    return {
        "total_cases": int(sanitized_stats.get('total_cases', 0)),
        "recovery_rate": float(sanitized_stats.get('recovery_rate', 0)),
        "total_recovered_usd": float(sanitized_stats.get('total_recovered_usd', 0)),
        "total_claimed_usd": float(sanitized_stats.get('total_claimed_usd', 0)),
        "avg_recovery_days": int(sanitized_stats.get('avg_recovery_days', 0)),
        "high_priority_cases": int(sanitized_stats.get('high_priority_cases', 0)),
        "success_stories": claim_service.get_recent_successes(db, limit=5)
    }

@router.get("/admin/claims", response_model=dict)
async def get_admin_claims(
    status_filter: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db),
    claim_service: ClaimService = Depends(get_claim_service)
):
    """Admin: Get paginated claims list with status filter for admin.html table."""
    # Support all statuses (not just pending)
    query = db.query(ClaimBlack).order_by(desc(ClaimBlack.created_at))
    
    if status_filter:
        query = query.filter(ClaimBlack.status == status_filter)
    
    total = query.count()
    claims = query.offset((page-1)*per_page).limit(per_page).all()
    
    items = [{
        "id": c.id,
        "case_id": c.case_id,
        "claimant": f"{c.first_name} {c.last_name}".strip(),
        "amount": c.amount_invested,
        "scam_type": c.scam_type.replace('_', ' ').title(),
        "priority": c.priority,
        "status": c.status,
        "specialist": c.assigned_specialist or 'Unassigned',
        "created": c.created_at.isoformat()
    } for c in claims]
    
    return {
        "items": items,
        "total": total,
        "page": page,
        "pages": (total + per_page - 1) // per_page,
        "page_size": per_page,
        "status_filter": status_filter
    }

@router.get("/claims/{case_id}", response_model=dict)
async def get_claim_detail(
    case_id: str,
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db)
):
    """Get detailed claim by case ID."""
    claim = db.query(ClaimBlack).filter(ClaimBlack.case_id == case_id.upper()).first()
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    
    return {
        "id": claim.id,
        "case_id": claim.case_id,
        "first_name": claim.first_name,
        "last_name": claim.last_name,
        "email": claim.email,
        "mobile": claim.mobile,
        "country": claim.country,
        "scam_type": claim.scam_type,
        "amount_invested": claim.amount_invested,
        "amount_recovered": float(claim.amount_recovered or 0),
        "case_description": claim.case_description,
        "status": claim.status,
        "priority": claim.priority,
        "assigned_specialist": claim.assigned_specialist,
        "created_at": claim.created_at.isoformat(),
        "updated_at": claim.updated_at.isoformat() if claim.updated_at else None,
        "recovery_days": claim.recovery_days
    }

class ClaimStatusUpdate(BaseModel):
    """Update claim status."""
    status: str
    notes: Optional[str] = None
    amount_recovered: Optional[float] = None
    recovery_days: Optional[int] = None

@router.put("/claims/{case_id}/status")
async def update_claim_status(
    case_id: str,
    update_data: ClaimStatusUpdate,
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db),
    claim_service: ClaimService = Depends(get_claim_service)
):
    """Update claim status and metrics (admin only)."""
    claim = db.query(ClaimBlack).filter(ClaimBlack.case_id == case_id.upper()).first()
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    
    claim_service.update_case_status(case_id, update_data.status, update_data.notes, update_data.amount_recovered)
    
    return {"message": "Claim status updated", "case_id": case_id, "new_status": update_data.status}

@router.put("/scam-report/{case_id}/update",
           response_model=ClaimReportResponse,
           summary="Update Case Information",
           description="Submit additional evidence or update case details.")
async def update_case(
    case_id: str,
    update_data: ClaimReportCreate = Body(..., embed=True),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Allow case owners to provide additional evidence."""
    case = db.query(ClaimBlack).filter(ClaimBlack.case_id == case_id.upper()).first()
    
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    
    # Ownership verification
    if current_user.id != case.user_id and current_user.email != case.email:
        raise HTTPException(status_code=403, detail="Unauthorized")
    
    # Update case with new evidence
    case.case_description += f"\n\n--- UPDATE {datetime.utcnow().strftime('%Y-%m-%d %H:%M')} ---\n{update_data.case_description}"
    case.updated_at = datetime.utcnow()
    
    db.commit()
    
    return ClaimReportResponse(
        success=True,
        case_id=case.case_id,
        message="Case updated successfully. Recovery team notified of new evidence.",
        status=case.status
    )

@router.get("/recent-successes", 
           response_model=List[dict],
           summary="Recent Recovery Success Stories",
           description="Anonymized success stories for transparency (last 30 days).")
async def recent_success_stories(
    db: Session = Depends(get_db),
    limit: int = 10
):
    """Show recent successful recoveries (anonymized)."""
    successes = db.query(ClaimBlack).filter(
        ClaimBlack.status == ClaimStatus.RECOVERED.value,
        ClaimBlack.created_at >= datetime.utcnow() - timedelta(days=30)
    ).order_by(desc(ClaimBlack.recovery_days)).limit(limit).all()
    
    return [
        {
            "case_id": case.case_id,
            "country": case.country,
            "scam_type": case.scam_type,
            "amount_recovered": float(case.amount_recovered or 0),
            "days_to_recover": case.recovery_days,
            "recovered_at": case.updated_at.isoformat() if case.updated_at else None
        }
        for case in successes
    ]