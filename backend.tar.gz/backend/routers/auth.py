from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.core.database import get_db
from backend.core.security import verify_password, get_password_hash, create_access_token
from backend.core.email_service import notify_bonus, build_email_verification_email
from backend.models.models import (
    User,
    PromoCode,
    Transaction,
    TransactionType,
    TransactionStatus,
    EmailVerificationToken,
    EmailOTPVerification,
)



from backend.schemas.schemas import UserRegister, UserLogin, Token
from datetime import datetime, timedelta
import secrets, threading, hashlib
import os


router = APIRouter(prefix="/auth", tags=["Authentication"])


def generate_wallet():
    return "0x" + secrets.token_hex(20)

def _send_bonus_email_async(email, name, amount, reason, user_id):

    """Send bonus notification in background thread so registration doesn't block."""
    from backend.core.database import SessionLocal
    db = SessionLocal()
    try:
        notify_bonus(email, name, amount, reason, db, user_id)
        db.commit()
    except Exception as e:
        db.rollback()
        print(f"Bonus email error: {e}")
    finally:
        db.close()

@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
def register(data: UserRegister, db: Session = Depends(get_db)):

    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    # ── Validate promo code if provided ─────────────────────────
    promo = None
    bonus_amount = 0.0  # No automatic signup bonus; only credited when a valid promo code is provided
    promo_reason = ""

    if data.promo_code:
        code_str = data.promo_code.strip().upper()
        promo = db.query(PromoCode).filter(
            PromoCode.code == code_str,
            PromoCode.is_active == True
        ).first()
        if not promo:
            raise HTTPException(status_code=400, detail="Invalid or expired promo code")
        if promo.used_count >= promo.max_uses:
            raise HTTPException(status_code=400, detail="Promo code has reached its usage limit")
        if promo.expires_at and datetime.utcnow() > promo.expires_at:
            raise HTTPException(status_code=400, detail="Promo code has expired")
        bonus_amount = promo.bonus_amount
        promo_reason = f"promo code <strong>{code_str}</strong> applied"


    # ── Create user ──────────────────────────────────────────────
    user = User(
        email=data.email,
        full_name=data.full_name,
        hashed_password=get_password_hash(data.password),
        mobile=data.mobile,
        country=data.country,
        address=data.address,
        city=data.city,
        state=data.state,
        date_of_birth=data.date_of_birth,
        wallet_address=generate_wallet(),
        balance=bonus_amount,
        bonus_credited=bool(promo),
        promo_code_used=promo.code if promo else None,
    )


    db.add(user)
    db.flush()  # get user.id before commit

    # ── Credit bonus transaction (only when promo is provided/valid) ─────────────────────────────────
    if promo:
        bonus_tx = Transaction(
            user_id=user.id,
            type=TransactionType.BONUS,
            amount=bonus_amount,
            status=TransactionStatus.COMPLETED,
            description=f"Welcome bonus — {promo_reason}",
            reference="BON-" + secrets.token_hex(6).upper()
        )
        db.add(bonus_tx)


    # ── Increment promo usage ────────────────────────────────────
    if promo:
        promo.used_count += 1

    # Mark registration complete (used to gate email verification)
    user.registration_completed = True
    db.commit()
    db.refresh(user)

    # ── Send email verification token/link ───────────────────────────────────
    email_token_plain = secrets.token_urlsafe(32)
    # Store hashed token only
    import hashlib
    token_hash = hashlib.sha256(email_token_plain.encode("utf-8")).hexdigest()
    expires_at = datetime.utcnow().replace(microsecond=0) + timedelta(hours=24)

    vt = EmailVerificationToken(
        user_id=user.id,
        token=token_hash,
        expires_at=expires_at,
    )
    db.add(vt)
    db.commit()

    # Use FRONTEND_BASE_URL (or API_BASE_URL) in production to avoid hardcoded localhost.
    # Falls back to relative link so deployments behind reverse proxies work.
    base_url = (
        os.getenv("FRONTEND_BASE_URL")
        or os.getenv("API_BASE_URL")
        or ""
    ).rstrip("/")

    if base_url:
        verification_link = f"{base_url}/auth/verify-email?token={email_token_plain}"
    else:
        verification_link = f"/auth/verify-email?token={email_token_plain}"


    subject, body = build_email_verification_email(verification_link)

    # Use send_email directly via existing email_service functions
    def _send_verify_email():

        from backend.core.email_service import send_email
        from backend.core.database import SessionLocal
        _db = SessionLocal()
        try:
            send_email(user.email, subject, body, _db, user.id, "email_verification")
            _db.commit()
        except Exception as e:
            _db.rollback()
            print(f"Email verification send error: {e}")
        finally:
            _db.close()

    t2 = threading.Thread(target=_send_verify_email, daemon=True)
    t2.start()

    # gate value used by the frontend to open verify-email-otp page only after registration.
    # (Backend also gates /auth/verify-email.)
    registration_gate_plain = secrets.token_urlsafe(32)

    token = create_access_token({"sub": user.email})

    # Return short-lived gate to frontend.
    # Store it server-side in the existing EmailVerificationToken table by using the gate hash.
    import hashlib as _hashlib
    gate_hash = _hashlib.sha256(registration_gate_plain.encode("utf-8")).hexdigest()
    gate_expires_at = datetime.utcnow().replace(microsecond=0) + timedelta(minutes=30)
    gate_vt = EmailVerificationToken(
        user_id=user.id,
        token=gate_hash,
        expires_at=gate_expires_at,
    )
    db.add(gate_vt)
    db.commit()


    # ── Send bonus email async ───────────────────────────────────

    t = threading.Thread(
        target=_send_bonus_email_async,
        args=(user.email, user.full_name, bonus_amount, promo_reason, user.id),
        daemon=True
    )
    t.start()

    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": 3600,
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "mobile": user.mobile,
            "country": user.country,
            "address": user.address,
            "city": user.city,
            "state": user.state,
            "date_of_birth": user.date_of_birth,
            "balance": user.balance,
            "wallet_address": user.wallet_address,
            "kyc_status": user.kyc_status,
            "bonus_amount": bonus_amount,
            "promo_used": promo.code if promo else None,
        }

    }

@router.get("/verify-email")
def verify_email(token: str, db: Session = Depends(get_db)):
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()

    vt = (
        db.query(EmailVerificationToken)
        .filter(EmailVerificationToken.token == token_hash)
        .first()
    )
    if not vt:
        raise HTTPException(status_code=400, detail="Invalid verification token")
    if vt.used_at is not None:
        raise HTTPException(status_code=400, detail="Verification token already used")
    if vt.expires_at < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Verification token expired")

    user = db.query(User).filter(User.id == vt.user_id).first()
    if not user:
        raise HTTPException(status_code=400, detail="User not found")

    # Require registration completion before allowing email verification
    if not getattr(user, "registration_completed", False):
        raise HTTPException(status_code=403, detail="Registration not completed yet")

    user.email_verified = True
    vt.used_at = datetime.utcnow()
    db.commit()

    return {"success": True, "message": "Email verified successfully. You can now log in."}




@router.post("/request-email-otp")
def request_email_otp(payload: dict, db: Session = Depends(get_db)):
    # payload expected: { email }
    email = (payload.get("email") or "").strip().lower()
    if not email:
        raise HTTPException(status_code=400, detail="Email is required")

    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Generate 6-digit code
    otp_plain = f"{secrets.randbelow(1000000):06d}"
    otp_hash = hashlib.sha256(otp_plain.encode("utf-8")).hexdigest()
    expires_at = datetime.utcnow().replace(microsecond=0) + timedelta(minutes=10)

    # Upsert OTP record
    existing = db.query(EmailOTPVerification).filter(EmailOTPVerification.user_id == user.id).first()
    if existing:
        existing.code_hash = otp_hash
        existing.expires_at = expires_at
        existing.used_at = None
    else:
        existing = EmailOTPVerification(
            user_id=user.id,
            code_hash=otp_hash,
            expires_at=expires_at,
        )
        db.add(existing)

    db.commit()

    # Send email (reuse send_email via email_service)
    from backend.core.email_service import send_email
    from backend.core.email_service import build_html_email as _build_html_email

    subject = "Your StrongNode verification code"
    body = f"<h2>Email Verification Code</h2><p>Your 6-digit code is: <strong style='color:#00d4aa;'>{otp_plain}</strong></p><p>This code expires in 10 minutes.</p>"
    # build_html_email is internal; keep simple HTML body for now
    # send_email will wrap body_html automatically.
    # We call send_email with notification_type='email_otp'
    send_email(email, subject, body, db, user.id, "email_otp")
    db.commit()

    return {"success": True, "message": "OTP sent to your email."}


@router.post("/verify-email-otp")
def verify_email_otp(payload: dict, db: Session = Depends(get_db)):
    email = (payload.get("email") or "").strip().lower()
    otp = (payload.get("otp") or "").strip()

    if not email or not otp:
        raise HTTPException(status_code=400, detail="Email and otp are required")
    if not otp.isdigit() or len(otp) != 6:
        raise HTTPException(status_code=400, detail="OTP must be 6 digits")

    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    rec = db.query(EmailOTPVerification).filter(EmailOTPVerification.user_id == user.id).first()
    if not rec:
        raise HTTPException(status_code=400, detail="No OTP requested")
    if rec.used_at is not None:
        raise HTTPException(status_code=400, detail="OTP already used")
    if rec.expires_at < datetime.utcnow():
        raise HTTPException(status_code=400, detail="OTP expired")

    otp_hash = hashlib.sha256(otp.encode("utf-8")).hexdigest()
    if rec.code_hash != otp_hash:
        raise HTTPException(status_code=400, detail="Invalid OTP")

    user.email_verified = True
    rec.used_at = datetime.utcnow()
    db.commit()

    return {"success": True, "message": "Email verified successfully!"}



@router.post("/login", response_model=Token)
def login(data: UserLogin, db: Session = Depends(get_db)):

    user = db.query(User).filter(User.email == data.email).first()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is disabled")
    # Allow admins to login without email verification.
    # Non-admin accounts must still verify email.
    if not user.email_verified and not user.is_admin:
        raise HTTPException(status_code=403, detail="Email not verified")



    token = create_access_token({"sub": user.email})
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": 3600,
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "balance": user.balance,
            "wallet_address": user.wallet_address,
            "kyc_status": user.kyc_status,
            "is_admin": user.is_admin,
            "promo_used": user.promo_code_used,
        }
    }

@router.get("/validate-promo/{code}")
def validate_promo(code: str, db: Session = Depends(get_db)):
    """Check a promo code before registration."""
    promo = db.query(PromoCode).filter(
        PromoCode.code == code.strip().upper(),
        PromoCode.is_active == True
    ).first()
    if not promo or promo.used_count >= promo.max_uses:
        raise HTTPException(status_code=404, detail="Invalid or expired promo code")
    if promo.expires_at and datetime.utcnow() > promo.expires_at:
        raise HTTPException(status_code=404, detail="Promo code has expired")
    return {"valid": True, "bonus_amount": promo.bonus_amount, "description": promo.description}
