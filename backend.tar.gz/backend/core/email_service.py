"""
Email Notification Service
--------------------------
Uses Python's built-in smtplib. Configure SMTP settings in AdminSettings table
or via environment variables. Falls back to console logging for development.
"""
import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from sqlalchemy.orm import Session


def get_smtp_config(db: Session) -> dict:
    """Read SMTP config from AdminSettings table or env vars."""
    from backend.models.models import AdminSettings
    config = {}
    try:
        rows = db.query(AdminSettings).filter(
            AdminSettings.key.in_(["smtp_host","smtp_port","smtp_user","smtp_pass","smtp_from","smtp_tls"])
        ).all()
        for r in rows:
            config[r.key] = r.value
    except Exception:
        pass
    return {
        "host":     config.get("smtp_host") or os.getenv("SMTP_HOST", "smtp.gmail.com"),
        "port":     int(config.get("smtp_port") or os.getenv("SMTP_PORT", "587")),
        "user":     config.get("smtp_user") or os.getenv("SMTP_USER", ""),
        "password": config.get("smtp_pass") or os.getenv("SMTP_PASS", ""),
        "from":     config.get("smtp_from") or os.getenv("SMTP_FROM", "noreply@cryptovault.io"),
        "tls":      (config.get("smtp_tls") or os.getenv("SMTP_TLS", "true")).lower() == "true",
    }


def build_html_email(subject: str, body_html: str) -> str:
    return f"""
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8">
<style>
  body{{font-family:'Segoe UI',Arial,sans-serif;background:#050810;margin:0;padding:0;}}
  .wrap{{max-width:560px;margin:40px auto;background:#111827;border:1px solid #1e2d4a;border-radius:16px;overflow:hidden;}}
  .header{{background:linear-gradient(135deg,#0a0f1e,#0f1628);padding:32px;text-align:center;border-bottom:1px solid #1e2d4a;}}
  .logo{{font-size:1.6rem;font-weight:800;color:#fff;letter-spacing:-0.5px;}}
  .logo span{{color:#00d4aa;}}
  .body{{padding:32px;color:#e8edf5;line-height:1.7;}}
  .highlight{{color:#00d4aa;font-weight:700;}}
  .amount{{font-size:2rem;font-weight:800;color:#00d4aa;font-family:monospace;}}
  .btn{{display:inline-block;background:#00d4aa;color:#050810;padding:14px 32px;border-radius:10px;text-decoration:none;font-weight:700;margin:20px 0;}}
  .footer{{padding:20px 32px;border-top:1px solid #1e2d4a;text-align:center;font-size:0.75rem;color:#6b7fa3;}}
  .divider{{height:1px;background:#1e2d4a;margin:20px 0;}}
</style>
</head>
<body>
  <div class="wrap">
    <div class="header">
      <div class="logo">Crypto<span>Vault</span></div>
      <div style="color:#6b7fa3;font-size:0.8rem;margin-top:6px;">Institutional Crypto Investment Platform</div>
    </div>
    <div class="body">{body_html}</div>
    <div class="footer">
      © {datetime.now().year} CryptoVault · <a href="#" style="color:#00d4aa;">Unsubscribe</a><br>
      This is an automated notification. Do not reply to this email.
    </div>
  </div>
</body>
</html>"""


def send_email(
    to_email: str,
    subject: str,
    body_html: str,
    db: Session,
    user_id: int = 0,
    notification_type: str = "general"
) -> bool:
    """Send an HTML email and log it to the database."""
    from backend.models.models import EmailNotificationLog

    full_html = build_html_email(subject, body_html)

    # Log to DB regardless of send success
    log = EmailNotificationLog(
        user_id=user_id,
        recipient_email=to_email,
        subject=subject,
        body=body_html,
        notification_type=notification_type,
        status="queued"
    )
    try:
        db.add(log)
        db.commit()
        db.refresh(log)
    except Exception:
        db.rollback()

    cfg = get_smtp_config(db)

    # If no SMTP configured, log to console (dev mode)
    if not cfg["user"] or not cfg["password"]:
        print(f"\n📧 [EMAIL - DEV MODE] To: {to_email}")
        print(f"   Subject: {subject}")
        print(f"   Type: {notification_type}")
        print(f"   Body preview: {body_html[:120]}...\n")
        try:
            log.status = "dev_logged"
            db.commit()
        except Exception:
            pass
        return True

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = f"CryptoVault <{cfg['from']}>"
        msg["To"] = to_email
        msg.attach(MIMEText(full_html, "html"))

        with smtplib.SMTP(cfg["host"], cfg["port"], timeout=10) as server:
            if cfg["tls"]:
                server.starttls()
            server.login(cfg["user"], cfg["password"])
            server.sendmail(cfg["from"], [to_email], msg.as_string())

        log.status = "sent"
        db.commit()
        return True
    except Exception as e:
        print(f"Email send failed: {e}")
        try:
            log.status = f"failed: {str(e)[:100]}"
            db.commit()
        except Exception:
            pass
        return False


# ── Notification Templates ──────────────────────────────────────────────────

def notify_profit(user_email: str, user_name: str, amount: float, new_balance: float,
                  plan_name: str, db: Session, user_id: int):
    subject = f"💰 Profit Credited: ${amount:.2f} — strongnode"
    body = f"""
<h2>Your Daily Profit Has Been Credited!</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<p>Great news! Your daily ROI profit from your <span class="highlight">{plan_name}</span> investment has been credited to your account.</p>
<div style="text-align:center;padding:24px;background:#0a0f1e;border-radius:12px;margin:20px 0;">
  <div style="font-size:0.85rem;color:#6b7fa3;margin-bottom:4px;">PROFIT CREDITED</div>
  <div class="amount">+${amount:.2f}</div>
  <div style="color:#6b7fa3;margin-top:8px;font-size:0.875rem;">New Balance: <strong style="color:#e8edf5;">${new_balance:.2f}</strong></div>
</div>
<p>Log in to your dashboard to view your full profit history, reinvest, or withdraw your earnings.</p>
<div style="text-align:center;"><a href="http://localhost:8000/dashboard" class="btn">View Dashboard</a></div>
<div class="divider"></div>
<p style="color:#6b7fa3;font-size:0.8rem;">To stop receiving profit notifications, update your preferences in dashboard settings.</p>
"""
    send_email(user_email, subject, body, db, user_id, "profit")


def notify_kyc_approved(user_email: str, user_name: str, db: Session, user_id: int):
    subject = "✅ KYC Verified — You're Now Fully Verified!"
    body = f"""
<h2>Identity Verification Approved</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<p>Congratulations! Your identity has been successfully verified. You now have full access to all CryptoVault features including:</p>
<ul style="color:#6b7fa3;line-height:2;">
  <li><span class="highlight">Deposits & Withdrawals</span> — unlimited transactions</li>
  <li><span class="highlight">Credit Advances</span> — borrow against your portfolio</li>
  <li><span class="highlight">Premium Plans</span> — access to Elite investment tiers</li>
</ul>
<div style="text-align:center;"><a href="http://localhost:8000/dashboard" class="btn">Start Investing</a></div>
"""
    send_email(user_email, subject, body, db, user_id, "kyc")


def notify_kyc_rejected(user_email: str, user_name: str, reason: str, db: Session, user_id: int):
    subject = "❌ KYC Review — Action Required"
    body = f"""
<h2>Identity Verification — Resubmission Required</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<p>Unfortunately, your KYC submission could not be approved. Here's why:</p>
<div style="background:#0a0f1e;border:1px solid #ff4d6d;border-radius:10px;padding:16px;margin:16px 0;color:#ff4d6d;">
  {reason or "Documents were unclear or incomplete. Please resubmit with clearer, valid documents."}
</div>
<p>Please resubmit your documents addressing the issue above. Make sure your documents are:</p>
<ul style="color:#6b7fa3;line-height:2;">
  <li>Clear and fully visible (no blur, glare, or cropping)</li>
  <li>Valid and not expired</li>
  <li>Matching your registered name exactly</li>
</ul>
<div style="text-align:center;"><a href="http://localhost:8000/dashboard" class="btn">Resubmit KYC</a></div>
"""
    send_email(user_email, subject, body, db, user_id, "kyc")


def notify_deposit(user_email: str, user_name: str, amount: float, ref: str, db: Session, user_id: int):
    subject = f"✅ Deposit Confirmed: ${amount:.2f}"
    body = f"""
<h2>Deposit Successfully Credited</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<p>Your deposit has been confirmed and credited to your account.</p>
<div style="text-align:center;padding:24px;background:#0a0f1e;border-radius:12px;margin:20px 0;">
  <div style="font-size:0.85rem;color:#6b7fa3;">AMOUNT CREDITED</div>
  <div class="amount">+${amount:.2f}</div>
  <div style="color:#6b7fa3;font-size:0.8rem;margin-top:8px;">Reference: {ref}</div>
</div>
<div style="text-align:center;"><a href="http://localhost:8000/dashboard" class="btn">View Dashboard</a></div>
"""
    send_email(user_email, subject, body, db, user_id, "deposit")


def notify_withdrawal(user_email: str, user_name: str, amount: float, ref: str, db: Session, user_id: int):
    subject = f"📤 Withdrawal Request: ${amount:.2f} — Processing"
    body = f"""
<h2>Withdrawal Request Received</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<p>Your withdrawal request has been submitted and is being processed.</p>
<div style="text-align:center;padding:24px;background:#0a0f1e;border-radius:12px;margin:20px 0;">
  <div style="font-size:0.85rem;color:#6b7fa3;">WITHDRAWAL AMOUNT</div>
  <div class="amount">${amount:.2f}</div>
  <div style="color:#6b7fa3;font-size:0.8rem;margin-top:8px;">Reference: {ref}</div>
</div>
<p style="color:#6b7fa3;">Processing time: 24–48 hours. You'll receive a confirmation once complete.</p>
"""
    send_email(user_email, subject, body, db, user_id, "withdrawal")


def notify_bonus(user_email: str, user_name: str, amount: float, reason: str, db: Session, user_id: int):
    subject = f"🎁 Bonus Credited: ${amount:.2f} — Welcome to CryptoVault!"
    body = f"""
<h2>Welcome Bonus Credited!</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<p>A welcome bonus of <span class="highlight">${amount:.2f}</span> has been credited to your account — {reason}.</p>
<div style="text-align:center;padding:24px;background:#0a0f1e;border-radius:12px;margin:20px 0;">
  <div style="font-size:0.85rem;color:#6b7fa3;">BONUS AMOUNT</div>
  <div class="amount">+${amount:.2f}</div>
</div>
<p>Use your bonus to start investing right away. Complete KYC verification to unlock full withdrawal access.</p>
<div style="text-align:center;"><a href="http://localhost:8000/dashboard" class="btn">Start Investing</a></div>
"""
    send_email(user_email, subject, body, db, user_id, "bonus")


def send_recovery_email(to_email: str, subject: str, body_html: str, db: Session, user_id: int = 0, notification_type: str = "recovery"):
    """Send recovery case confirmation email."""
    send_email(to_email, subject, body_html, db, user_id, notification_type)


def build_email_verification_email(verification_link: str) -> tuple[str, str]:
    subject = "✅ Verify your email address"
    body = f"""


<h2>Email Verification Required</h2>
<p>To protect your account, please verify that this email address belongs to you.</p>
<div style="text-align:center;margin:18px 0;">
  <a href="{verification_link}" class="btn">Verify Email</a>
</div>
<p>If you did not create an account, you can safely ignore this email.</p>
<p style="color:#6b7fa3;font-size:0.8rem;">This verification link will expire soon.</p>
"""
    return subject, body

