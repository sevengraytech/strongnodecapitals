from pydantic import BaseModel, EmailStr, field_validator, ConfigDict
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum
from backend.models.models import (
    TransactionType, TransactionStatus, InvestmentStatus, 
    LoanStatus, KYCStatus, ClaimStatus
)
from backend.models.models import ClaimStatus
# ═══════════════════════════════════════════════════════════════════════════════
# USER SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════

class UserRegister(BaseModel):
    """User registration schema with validation."""
    model_config = ConfigDict(from_attributes=True)

    email: EmailStr
    full_name: str
    password: str

    mobile: str
    country: str
    address: str
    city: str
    state: str
    date_of_birth: str  # YYYY-MM-DD

    promo_code: Optional[str] = None

    @field_validator('full_name')
    @classmethod
    def validate_full_name(cls, v: str) -> str:
        v = v.strip()
        if len(v) < 2:
            raise ValueError('Full name must be at least 2 characters')
        if len(v) > 100:
            raise ValueError('Full name too long (max 100 characters)')
        return v.title()

    @field_validator('mobile')
    @classmethod
    def validate_mobile(cls, v: str) -> str:
        v = v.strip()
        if len(v) < 8 or len(v) > 20:
            raise ValueError('Invalid mobile number format')
        return v

    @field_validator('country', 'city', 'state')
    @classmethod
    def validate_location(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError('This field is required')
        if len(v) > 100:
            raise ValueError('Value too long (max 100 characters)')
        return v

    @field_validator('address')
    @classmethod
    def validate_address(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError('Address is required')
        if len(v) > 1000:
            raise ValueError('Address too long (max 1000 characters)')
        return v

    @field_validator('date_of_birth')
    @classmethod
    def validate_dob(cls, v: str) -> str:
        v = v.strip()
        # Expect YYYY-MM-DD from <input type="date">
        try:
            dt = datetime.strptime(v, '%Y-%m-%d')
        except Exception:
            raise ValueError('Date of birth must be in format YYYY-MM-DD')
        # Basic sanity: user must be born before today
        if dt.date() >= datetime.utcnow().date():
            raise ValueError('Date of birth must be in the past')
        return v

    @field_validator('password')
    @classmethod
    def validate_password(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters')
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain at least one digit')
        return v


class UserLogin(BaseModel):
    """User login schema."""
    model_config = ConfigDict(from_attributes=True)
    
    email: EmailStr
    password: str

class Token(BaseModel):
    """JWT Token response."""
    model_config = ConfigDict(from_attributes=True)
    
    access_token: str
    token_type: str = "bearer"
    expires_in: int = 3600
    user: Dict[str, Any]

class UserOut(BaseModel):
    """Complete user profile response."""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    email: str
    full_name: str
    balance: float
    total_invested: float = 0.0
    total_profit: float = 0.0
    total_withdrawn: float = 0.0
    wallet_address: Optional[str] = None
    btc_wallet_address: Optional[str] = None
    usdt_wallet_address: Optional[str] = None
    kyc_status: KYCStatus = KYCStatus.PENDING
    is_admin: bool = False
    email_notifications: bool = True
    phone_notifications: bool = False
    created_at: datetime
    last_login: Optional[datetime] = None

# ═══════════════════════════════════════════════════════════════════════════════
# TRANSACTION SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════

class DepositRequest(BaseModel):
    """Crypto deposit request."""
    model_config = ConfigDict(from_attributes=True)
    
    amount: float
    crypto_type: str = "USDT"  # Default to stablecoin

    @field_validator('amount')
    @classmethod
    def validate_amount(cls, v: float) -> float:
        if v < 10:
            raise ValueError('Minimum deposit is $10')
        if v > 1000000:
            raise ValueError('Maximum deposit is $1,000,000')
        return round(v, 2)

    @field_validator('crypto_type')
    @classmethod
    def validate_crypto(cls, v: str) -> str:
        allowed = {'BTC', 'ETH', 'USDT', 'USDC', 'TRX'}
        if v.upper() not in allowed:
            raise ValueError(f'Crypto type must be one of: {", ".join(allowed)}')
        return v.upper()

class WithdrawRequest(BaseModel):
    """Crypto withdrawal request."""
    model_config = ConfigDict(from_attributes=True)
    
    amount: float
    wallet_address: str
    crypto_type: str = "USDT"

    @field_validator('amount')
    @classmethod
    def validate_withdraw_amount(cls, v: float) -> float:
        if v < 20:
            raise ValueError('Minimum withdrawal is $20')
        if v > 500000:
            raise ValueError('Maximum withdrawal is $500,000')
        return round(v, 2)

class TransactionOut(BaseModel):
    """Transaction history response."""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    type: TransactionType
    amount: float
    status: TransactionStatus
    crypto_type: Optional[str] = None
    wallet_address: Optional[str] = None
    description: str
    reference: str
    fee: float = 0.0
    created_at: datetime

class PaginatedTransactions(BaseModel):
    """Paginated transaction response."""
    model_config = ConfigDict(from_attributes=True)
    
    items: List[TransactionOut]
    total: int
    page: int
    pages: int
    page_size: int

# ═══════════════════════════════════════════════════════════════════════════════
# INVESTMENT SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════

class InvestmentPlanOut(BaseModel):
    """Investment plan details."""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    name: str
    daily_roi: float  # e.g. 0.015 = 1.5%
    min_amount: float
    max_amount: float
    duration_days: int
    description: str
    is_active: bool = True
    total_active_investors: int = 0

class InvestRequest(BaseModel):
    """Investment creation request."""
    model_config = ConfigDict(from_attributes=True)
    
    plan_id: int
    amount: float

    @field_validator('amount')
    @classmethod
    def validate_invest_amount(cls, v: float) -> float:
        if v < 50:
            raise ValueError('Minimum investment is $50')
        return round(v, 2)

class ClaimInvestmentRequest(BaseModel):
    """Investment claim request."""
    model_config = ConfigDict(from_attributes=True)
    
    investment_id: int
    amount: float = None  # Optional, auto-calculate principal if not provided

    @field_validator('amount')
    @classmethod
    def validate_claim_amount(cls, v: float) -> float:
        if v is None:
            return v  # Will auto-calculate
        if v < 50:
            raise ValueError('Minimum claim amount is $50')
        return round(v, 2)

class InvestmentOut(BaseModel):
    """Active investment details."""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    plan_id: int
    amount: float
    roi_earned: float = 0.0
    status: InvestmentStatus
    start_date: datetime
    end_date: Optional[datetime] = None
    total_profit_earned: float = 0.0
    daily_profit: float = 0.0  
    days_remaining: Optional[int] = None
    plan: InvestmentPlanOut

class ProfitLogOut(BaseModel):
    """Daily profit accrual log."""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    investment_id: int
    amount: float
    date: datetime
    description: str

# ═══════════════════════════════════════════════════════════════════════════════
# LOAN SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════

class LoanRequestCreate(BaseModel):
    """Loan application request."""
    model_config = ConfigDict(from_attributes=True)
    
    amount: float
    purpose: str = "Business Expansion"
    duration_months: int = 12

    @field_validator('amount')
    @classmethod
    def validate_loan_amount(cls, v: float) -> float:
        if v < 50:
            raise ValueError('Minimum loan amount is $50')
        if v > 500000:
            raise ValueError('Maximum loan amount is $500,000')
        return round(v, 0)

class LoanRepayRequest(BaseModel):
    """Loan repayment request."""
    model_config = ConfigDict(from_attributes=True)
    
    loan_id: int
    amount: float

class LoanOut(BaseModel):
    """Loan details response."""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    amount: float
    interest_rate: float
    status: LoanStatus
    purpose: str
    duration_months: int
    monthly_payment: float
    total_repaid: float = 0.0
    remaining_balance: float
    created_at: datetime
    approved_at: Optional[datetime]
    due_date: Optional[datetime]

# ═══════════════════════════════════════════════════════════════════════════════
# CLAIMBACK & RECOVERY SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════

class ClaimReportCreate(BaseModel):
    """Scam recovery case submission."""
    model_config = ConfigDict(from_attributes=True)
    
    first_name: str
    last_name: str
    email: EmailStr
    mobile: str
    country: str
    scam_type: str
    amount_invested: float
    case_description: str
    evidence_links: Optional[List[str]] = None

    @field_validator('first_name', 'last_name')
    @classmethod
    def validate_names(cls, v: str) -> str:
        v = v.strip()
        if len(v) < 2 or len(v) > 50:
            raise ValueError('Name must be 2-50 characters')
        return v.title()

    @field_validator('mobile')
    @classmethod
    def validate_mobile(cls, v: str) -> str:
        v = v.strip()
        if len(v) < 8 or len(v) > 20:
            raise ValueError('Invalid mobile number format')
        return v

    @field_validator('amount_invested')
    @classmethod
    def validate_claim_amount(cls, v: float) -> float:
        if v < 100:
            raise ValueError('Minimum claim amount is $100')
        if v > 10000000:
            raise ValueError('Maximum claim amount is $10,000,000')
        return round(v, 2)


        v = v.strip()
        if len(v) < 50:
            raise ValueError('Case description must be at least 50 characters')
        if len(v) > 10000:
            raise ValueError('Case description too long (max 10,000 characters)')
        return v

    @field_validator('evidence_links')
    @classmethod
    def validate_evidence_links(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        if not v:
            return None
        for link in v:
            if not link.startswith(('http://', 'https://')):
                raise ValueError('All evidence links must be valid URLs')
        return v

class ClaimReportResponse(BaseModel):
    """Scam recovery case response."""
    model_config = ConfigDict(from_attributes=True)
    
    success: bool
    case_id: Optional[str] = None
    message: str
    status: Optional[ClaimStatus] = None
    priority: Optional[int] = None
    next_steps: List[str] = []
    estimated_recovery_time: Optional[str] = None
    recovery_stats: Optional[Dict[str, Any]] = None
    contact_info: Optional[Dict[str, str]] = None

class ClaimStatusUpdate(BaseModel):
    """Admin case status update."""
    model_config = ConfigDict(from_attributes=True)
    
    status: ClaimStatus
    notes: Optional[str] = None
    amount_recovered: Optional[float] = None
    recovery_days: Optional[int] = None




# ═══════════════════════════════════════════════════════════════════════════════
# KYC & VERIFICATION SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════

class KYCUploadRequest(BaseModel):
    """KYC document upload."""
    model_config = ConfigDict(from_attributes=True)
    
    document_type: str  # passport, drivers_license, utility_bill
    file_name: str
    file_size: int
    file_hash: str  # SHA256

class KYCDocumentOut(BaseModel):
    """KYC document status."""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    document_type: str
    status: str  # pending, approved, rejected
    rejection_reason: Optional[str] = None
    uploaded_at: datetime
    reviewed_at: Optional[datetime] = None

# ═══════════════════════════════════════════════════════════════════════════════
# ADMIN & REPORTING SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════

class AdminDashboardStats(BaseModel):
    """Admin dashboard metrics."""
    model_config = ConfigDict(from_attributes=True)
    
    total_users: int
    active_users_24h: int
    total_deposits: float
    total_withdrawals: float
    total_aum: float
    pending_kyc: int
    pending_claims: int
    recovery_rate: float

class PlatformStats(BaseModel):
    """Public platform statistics."""
    model_config = ConfigDict(from_attributes=True)
    
    total_users: int
    total_aum: float
    avg_roi: float
    uptime_30d: float
    recovery_success_rate: float
    active_plans: int