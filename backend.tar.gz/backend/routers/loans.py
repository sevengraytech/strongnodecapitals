from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.core.database import get_db
from backend.core.security import get_current_user
from backend.models.models import User, LoanRequest, LoanStatus, Transaction, TransactionType, TransactionStatus
from backend.schemas.schemas import LoanRequestCreate, LoanOut, LoanRepayRequest
from typing import List
from datetime import datetime, timedelta
import secrets

router = APIRouter(prefix="/loans", tags=["Loans"])

@router.post("/request", response_model=LoanOut)
def request_loan(data: LoanRequestCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if data.amount < 50:
        raise HTTPException(status_code=400, detail="Minimum loan amount is $50")
    # Max loan = 50% of total invested
    max_loan = current_user.total_invested * 0.5
    if max_loan < 50:
        raise HTTPException(status_code=400, detail="You need at least $100 invested to request a loan")
    if data.amount > max_loan:
        raise HTTPException(status_code=400, detail=f"Maximum loan amount is ${round(max_loan, 2)} (50% of invested)")
    
    # Check for existing active loan
    existing = db.query(LoanRequest).filter(
        LoanRequest.user_id == current_user.id,
        LoanRequest.status.in_([LoanStatus.PENDING, LoanStatus.APPROVED])
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="You already have an active loan request")
    
    interest_rate = 5.0
    monthly_payment = data.amount * (1 + interest_rate / 100) / data.duration_months
    remaining_balance = data.amount
    due_date = datetime.utcnow() + timedelta(days=data.duration_months * 30)

    loan = LoanRequest(
        user_id=current_user.id,
        amount=data.amount,
        interest_rate=interest_rate,
        duration_months=data.duration_months,
        monthly_payment=monthly_payment,
        remaining_balance=remaining_balance,
        purpose=data.purpose or "Business Expansion",
        status=LoanStatus.APPROVED,  # Auto-approve for demo
        approved_at=datetime.utcnow(),
        due_date=due_date
    )
    current_user.balance += data.amount
    db.add(loan)
    tx = Transaction(
        user_id=current_user.id,
        type=TransactionType.LOAN,
        amount=data.amount,
        status=TransactionStatus.COMPLETED,
        description=f"Loan approved: ${data.amount:.2f} over {data.duration_months} months @ {interest_rate}% interest",
        reference="LNS-" + secrets.token_hex(6).upper()
    )
    db.add(tx)
    db.commit()
    db.refresh(loan)
    return loan

@router.get("/my", response_model=List[LoanOut])
def get_my_loans(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(LoanRequest).filter(LoanRequest.user_id == current_user.id)\
        .order_by(LoanRequest.created_at.desc()).all()

@router.post("/repay")
def repay_loan(data: LoanRepayRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    loan = db.query(LoanRequest).filter(
        LoanRequest.id == data.loan_id,
        LoanRequest.user_id == current_user.id,
        LoanRequest.status == LoanStatus.APPROVED
    ).first()
    if not loan:
        raise HTTPException(status_code=404, detail="Active loan not found")
    
    repay_amount = loan.remaining_balance + (loan.remaining_balance * loan.interest_rate / 100 / 12 * loan.duration_months)
    if current_user.balance < repay_amount:
        raise HTTPException(status_code=400, detail=f"Insufficient balance. Need ${round(repay_amount, 2)}")
    
    current_user.balance -= repay_amount
    loan.total_repaid += repay_amount
    loan.remaining_balance = 0.0
    loan.status = LoanStatus.REPAID
    loan.repaid_at = datetime.utcnow()
    
    tx = Transaction(
        user_id=current_user.id,
        type=TransactionType.LOAN_REPAY,
        amount=repay_amount,
        status=TransactionStatus.COMPLETED,
        description=f"Full loan repayment (${round(loan.amount,2)} principal + interest)",
        reference="RPY-" + secrets.token_hex(6).upper()
    )
    db.add(tx)
    db.commit()
    return {"message": "Loan repaid successfully", "amount_repaid": round(repay_amount, 2), "new_balance": round(current_user.balance, 2)}
